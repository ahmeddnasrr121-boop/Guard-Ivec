
import React, { useState, useMemo, useEffect } from 'react';
import { 
  Usb, Monitor, Search as SearchIcon, Cpu, X, Target, ShieldCheck, Printer, 
  MousePointer2, Loader2, CheckCircle2
} from 'lucide-react';
import { Device, AgentStatus, RiskLevel } from '../types';
import { useTranslation } from '../App';
import { api } from '../services/api';

const Devices: React.FC = () => {
  const { lang, t } = useTranslation();
  const isRtl = lang === 'ar';
  const [devices, setDevices] = useState<Device[]>([]);
  const [selectedDevice, setSelectedDevice] = useState<Device | null>(null);
  const [executingCommand, setExecutingCommand] = useState<string | null>(null);
  const [commandSuccess, setCommandSuccess] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isUpdatingPolicy, setIsUpdatingPolicy] = useState(false);

  useEffect(() => {
    api.getDevices().then(setDevices).catch(console.error);
    const interval = setInterval(() => api.getDevices().then(setDevices), 5000);
    return () => clearInterval(interval);
  }, []);

  const filteredDevices = useMemo(() => {
    return devices.filter(d => 
      d.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
      d.employeeName.toLowerCase().includes(searchQuery.toLowerCase())
    );
  }, [devices, searchQuery]);

  const toggleFeature = async (key: string) => {
    if (!selectedDevice) return;
    const currentPolicy = (selectedDevice as any).policy || {};
    const newPolicy = { ...currentPolicy, [key]: !currentPolicy[key] };
    
    setIsUpdatingPolicy(true);
    try {
      await api.updateDevicePolicy(selectedDevice.id, newPolicy);
      const updatedDevices = await api.getDevices();
      setDevices(updatedDevices);
      const newSelected = updatedDevices.find(d => d.id === selectedDevice.id);
      if (newSelected) setSelectedDevice(newSelected);
    } finally {
      setIsUpdatingPolicy(false);
    }
  };

  const handleCommand = (cmd: string) => {
    if (!selectedDevice) return;
    setExecutingCommand(cmd);
    api.sendCommand(selectedDevice.id, cmd.toUpperCase() as any).then(() => {
      setExecutingCommand(null);
      setCommandSuccess(cmd);
      setTimeout(() => setCommandSuccess(null), 3000);
    });
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      <div className={`flex justify-between items-end ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
        <div className={isRtl ? 'text-right' : 'text-left'}>
          <h2 className="text-4xl font-extrabold tracking-tighter mb-2">{t('agents')}</h2>
          <p className="text-zinc-500 font-medium">{devices.length} Registered • Policy Engine Stable</p>
        </div>
      </div>

      <div className={`grid grid-cols-1 xl:grid-cols-12 gap-10`}>
        <div className="xl:col-span-7 space-y-6">
          <div className="glass rounded-[2.5rem] overflow-hidden">
            <div className={`p-6 bg-zinc-900/30 flex justify-between items-center border-b border-zinc-800/50 ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
              <div className="relative">
                <SearchIcon className={`absolute ${isRtl ? 'right-3' : 'left-3'} top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-600`} />
                <input 
                  type="text" value={searchQuery} onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder={t('search')} className={`bg-transparent text-xs font-bold ${isRtl ? 'pr-10 text-right' : 'pl-10 text-left'} focus:outline-none w-64`} 
                />
              </div>
            </div>
            <table className={`w-full ${isRtl ? 'text-right' : 'text-left'}`}>
              <tbody className="divide-y divide-zinc-800/50">
                {filteredDevices.map((device) => (
                  <tr 
                    key={device.id} onClick={() => setSelectedDevice(device)}
                    className={`cursor-pointer transition-all hover:bg-zinc-800/30 ${selectedDevice?.id === device.id ? 'bg-emerald-500/5' : ''}`}
                  >
                    <td className="px-8 py-6">
                      <div className={`flex items-center gap-4 ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
                        <div className={`p-3 rounded-2xl glass ${device.status === AgentStatus.ONLINE ? 'text-emerald-500' : 'text-zinc-600'}`}>
                          <Monitor className="w-5 h-5" />
                        </div>
                        <div>
                          <p className="font-extrabold text-zinc-100">{device.name}</p>
                          <p className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider">{device.employeeName}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-6 text-right">
                       <div className="flex flex-col items-end">
                          <span className={`text-lg font-black ${device.predictiveRiskScore > 50 ? 'text-rose-500' : 'text-zinc-400'}`}>{device.predictiveRiskScore}%</span>
                          <span className="text-[8px] font-bold text-zinc-600 uppercase">Live Risk</span>
                       </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="xl:col-span-5">
          <div className="glass p-10 rounded-[3rem] sticky top-28 bg-zinc-950/80 shadow-2xl">
            {selectedDevice ? (
              <div className="space-y-10">
                <div className="text-center">
                  <div className="w-16 h-16 bg-zinc-800 rounded-3xl flex items-center justify-center mx-auto mb-4 border border-zinc-700 relative">
                     <Cpu className="w-8 h-8 text-emerald-500" />
                  </div>
                  <h3 className="text-xl font-black text-zinc-100">{selectedDevice.name}</h3>
                  <p className="text-[9px] font-black text-zinc-500 uppercase tracking-widest mt-1">{selectedDevice.ipAddress}</p>
                </div>

                <div className="space-y-2">
                  <p className={`text-[10px] font-black text-zinc-600 uppercase tracking-[0.3em] mb-4 ${isRtl ? 'text-right' : 'text-left'}`}>
                    Tactical Policy {isUpdatingPolicy && <Loader2 className="inline w-3 h-3 animate-spin ml-2" />}
                  </p>
                  <div className="grid grid-cols-1 gap-2">
                    {[
                      { key: 'fileMonitoring', label: 'File Intel', icon: <SearchIcon /> },
                      { key: 'usbMonitoring', label: 'USB Guard', icon: <Usb /> },
                      { key: 'printMonitoring', label: 'Print Logic', icon: <Printer /> },
                      { key: 'idleTracking', label: 'Presence Tracking', icon: <MousePointer2 /> },
                    ].map((f) => {
                      const isActive = (selectedDevice as any).policy?.[f.key];
                      return (
                        <button 
                          key={f.key} onClick={() => toggleFeature(f.key)}
                          className={`w-full flex items-center justify-between p-4 rounded-2xl border transition-all ${
                            isActive ? 'bg-zinc-900 border-emerald-500/20 text-zinc-200 shadow-lg' : 'bg-zinc-950/50 border-zinc-800 text-zinc-500 opacity-60'
                          }`}
                        >
                          <div className="flex items-center gap-3">
                            {React.cloneElement(f.icon as React.ReactElement, { className: 'w-4 h-4' })}
                            <span className="text-xs font-bold tracking-tight">{f.label}</span>
                          </div>
                          {isActive ? <div className="w-2 h-2 rounded-full bg-emerald-500 shadow-[0_0_8px_#10b981]" /> : <X className="w-4 h-4" />}
                        </button>
                      );
                    })}
                  </div>
                </div>

                <button 
                   disabled={!!executingCommand} onClick={() => handleCommand('lock')}
                   className={`w-full py-4 ${commandSuccess === 'lock' ? 'bg-emerald-500 text-zinc-950' : 'bg-zinc-100 text-zinc-950'} font-black rounded-2xl text-[10px] uppercase tracking-widest hover:bg-emerald-400 transition-all flex items-center justify-center gap-2`}
                >
                  {executingCommand === 'lock' ? <Loader2 className="w-3 h-3 animate-spin" /> : commandSuccess === 'lock' ? <CheckCircle2 className="w-3 h-3" /> : null}
                  {executingCommand === 'lock' ? 'LOCKING...' : commandSuccess === 'lock' ? 'LOCKED' : t('lockdown')}
                </button>
              </div>
            ) : (
              <div className="py-20 text-center text-zinc-800 uppercase font-black">Select Edge Agent</div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Devices;
