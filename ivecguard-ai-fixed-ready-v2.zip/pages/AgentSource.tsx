
import React from 'react';
import { Terminal, Download, FileCode, Server, ShieldCheck, Cpu } from 'lucide-react';
import { useTranslation } from '../App';

const AgentSource: React.FC = () => {
  const { lang, t } = useTranslation();
  const isRtl = lang === 'ar';

  const downloadFile = (name: string, content: string) => {
    const element = document.createElement("a");
    const file = new Blob([content], {type: 'text/plain'});
    element.href = URL.createObjectURL(file);
    element.download = name;
    document.body.appendChild(element);
    element.click();
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      <div className={`flex justify-between items-end ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
        <div className={isRtl ? 'text-right' : 'text-left'}>
          <h2 className="text-4xl font-extrabold tracking-tighter mb-2">Deploy & Source</h2>
          <p className="text-zinc-500 font-medium">Production-ready Agent binaries and Backend infrastructure.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <div className="glass p-8 rounded-[2.5rem] flex flex-col h-full">
          <div className={`flex items-center gap-4 mb-8 ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
            <div className="w-12 h-12 bg-emerald-500/10 rounded-2xl flex items-center justify-center text-emerald-500">
              <Cpu className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-bold">Windows Device Agent</h3>
              <p className="text-xs text-zinc-500">Python 3.10+ • Compiled as Service</p>
            </div>
          </div>
          
          <div className="bg-zinc-950 rounded-2xl p-6 mb-6 flex-1 overflow-auto max-h-60 border border-zinc-800">
            <code className="text-[10px] text-zinc-400 font-mono leading-relaxed whitespace-pre">
{`import os
import win32print
from watchdog.observers import Observer

class IVECGuardAgent:
    def __init__(self, server_url, token):
        self.url = server_url
        self.token = token
    ...`}
            </code>
          </div>

          <button 
            onClick={() => alert("Deployment package generation started. Check email.")}
            className="w-full py-4 bg-emerald-500 text-zinc-950 font-black rounded-2xl text-xs uppercase tracking-widest hover:bg-emerald-400 transition-all flex items-center justify-center gap-2"
          >
            <Download className="w-4 h-4" />
            Download Compiled .EXE (Installer)
          </button>
        </div>

        <div className="glass p-8 rounded-[2.5rem] flex flex-col h-full">
          <div className={`flex items-center gap-4 mb-8 ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
            <div className="w-12 h-12 bg-blue-500/10 rounded-2xl flex items-center justify-center text-blue-500">
              <Server className="w-6 h-6" />
            </div>
            <div>
              <h3 className="text-xl font-bold">Backend Infrastructure</h3>
              <p className="text-xs text-zinc-500">FastAPI • PostgreSQL • Docker</p>
            </div>
          </div>

          <div className="space-y-4 flex-1">
            <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-xl flex items-center justify-between">
              <div className="flex items-center gap-3">
                <FileCode className="w-5 h-5 text-zinc-500" />
                <span className="text-sm font-bold">docker-compose.yml</span>
              </div>
              <Download className="w-4 h-4 text-zinc-600 cursor-pointer hover:text-white" />
            </div>
            <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-xl flex items-center justify-between">
              <div className="flex items-center gap-3">
                <FileCode className="w-5 h-5 text-zinc-500" />
                <span className="text-sm font-bold">main_api.py</span>
              </div>
              <Download className="w-4 h-4 text-zinc-600 cursor-pointer hover:text-white" />
            </div>
            <div className="p-4 bg-zinc-900 border border-zinc-800 rounded-xl flex items-center justify-between">
              <div className="flex items-center gap-3">
                <FileCode className="w-5 h-5 text-zinc-500" />
                <span className="text-sm font-bold">risk_engine.py</span>
              </div>
              <Download className="w-4 h-4 text-zinc-600 cursor-pointer hover:text-white" />
            </div>
          </div>

          <button className="w-full py-4 mt-6 bg-zinc-100 text-zinc-950 font-black rounded-2xl text-xs uppercase tracking-widest hover:bg-white transition-all">
            Deploy via Kubernetes Helm Chart
          </button>
        </div>
      </div>

      <div className="bg-emerald-500/5 border border-emerald-500/10 p-10 rounded-[3rem]">
        <div className={`flex items-center gap-6 ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
          <div className="w-16 h-16 bg-emerald-500/20 rounded-3xl flex items-center justify-center text-emerald-500">
            <ShieldCheck className="w-8 h-8" />
          </div>
          <div className={isRtl ? 'text-right' : 'text-left'}>
            <h4 className="text-xl font-bold text-emerald-400">Agent Protection Protocol</h4>
            <p className="text-zinc-400 leading-relaxed max-w-2xl mt-2">
              The IVECGuard Agent includes anti-tampering logic that detects unauthorized process termination or service modification. 
              Upon detection, the agent executes an emergency "Lock & Alert" sequence to prevent data exfiltration.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AgentSource;
