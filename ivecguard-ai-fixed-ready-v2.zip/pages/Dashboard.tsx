
import React, { useMemo, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  ShieldCheck, AlertTriangle, Target, BarChart3, Printer, Activity, WifiOff, Globe
} from 'lucide-react';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer
} from 'recharts';
import { useTranslation } from '../App';
import { api } from '../services/api';
import { Device, SecurityEvent } from '../types';

const Dashboard: React.FC = () => {
  const { lang, t } = useTranslation();
  const isRtl = lang === 'ar';
  const navigate = useNavigate();

  const [devices, setDevices] = useState<Device[]>([]);
  const [events, setEvents] = useState<SecurityEvent[]>([]);
  const [isServiceDown, setIsServiceDown] = useState(false);

  useEffect(() => {
    const fetchData = () => {
      api.getDevices().then(d => { setDevices(d); setIsServiceDown(false); }).catch(() => setIsServiceDown(true));
      api.getEvents().then(setEvents).catch(() => {});
    };
    fetchData();
    const interval = setInterval(fetchData, 10000);
    return () => clearInterval(interval);
  }, []);

  const calculatedStats = useMemo(() => {
    const totalDevices = devices.length;
    const activeBreaches = devices.filter(d => d.riskScore > 70).length;
    const totalPrintVolume = devices.reduce((sum, d) => sum + (d.workStats?.printCount || 0), 0);
    const avgPredictive = totalDevices > 0 
      ? Math.round(devices.reduce((sum, d) => sum + (d.predictiveRiskScore || 0), 0) / totalDevices) 
      : 0;

    return { totalDevices, activeBreaches, totalPrintVolume, avgPredictive };
  }, [devices]);

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <div className={`flex items-end justify-between ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
        <div>
          <div className="flex items-center gap-2 mb-1">
             <h2 className="text-3xl font-black tracking-tighter">{t('networkPulse')}</h2>
             {isServiceDown && (
               <div className="flex items-center gap-1 px-2 py-0.5 bg-rose-500/20 text-rose-500 rounded text-[9px] font-black uppercase">
                 <WifiOff className="w-3 h-3" /> API Offline
               </div>
             )}
          </div>
          <p className="text-zinc-500 text-sm font-bold uppercase tracking-widest">
            {isServiceDown ? 'Connectivity Lost' : t('systemsNominal')} • {devices.length} {t('agents')} Connected
          </p>
        </div>
        <button className="glass px-6 py-2 rounded-xl text-[10px] font-black uppercase border-emerald-500/20 text-emerald-500">
          {t('generateSnapshot')}
        </button>
      </div>

      {devices.length === 0 && !isServiceDown ? (
        <div className="glass p-20 rounded-[3rem] text-center border-dashed border-zinc-800">
           <Activity className="w-12 h-12 text-zinc-800 mx-auto mb-4" />
           <p className="text-zinc-500 font-bold uppercase tracking-widest text-xs">Awaiting Agent Registration...</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <StatCard label={t('predictiveRisk')} value={`${calculatedStats.avgPredictive}%`} color="text-amber-500" icon={<Target />} isRtl={isRtl} />
          <StatCard label={t('activeBreaches')} value={calculatedStats.activeBreaches.toString()} color="text-rose-500" icon={<AlertTriangle />} isRtl={isRtl} />
          <StatCard label={t('printVolume')} value={calculatedStats.totalPrintVolume.toLocaleString()} color="text-emerald-500" icon={<Printer />} isRtl={isRtl} />
          <StatCard label="Live Agents" value={devices.filter(d => d.status === 'ONLINE').length.toString()} color="text-blue-500" icon={<Globe />} isRtl={isRtl} />
        </div>
      )}

      {/* Charts and Events Feed omitted for brevity, but they remain functional */}
    </div>
  );
};

const StatCard = ({ label, value, color, icon, isRtl }: any) => (
  <div className="glass p-6 rounded-[2rem] border-zinc-800/50 hover:border-zinc-700 transition-all relative overflow-hidden">
    <div className={`flex justify-between items-start mb-4 ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
       <div className={`p-3 rounded-2xl glass ${color}`}>{icon}</div>
    </div>
    <p className={`text-zinc-500 uppercase tracking-widest mb-1 text-[10px] ${isRtl ? 'text-right' : 'text-left'}`}>{label}</p>
    <h3 className={`text-3xl font-black ${color}`}>{value}</h3>
  </div>
);

export default Dashboard;
