
import React, { useState } from 'react';
import { 
  BrainCircuit, 
  Sparkles, 
  RefreshCw, 
  ShieldAlert, 
  ChevronRight,
  Zap,
  LineChart,
  Target,
  ShieldCheck,
  TrendingUp,
  Clock,
  LayoutList
} from 'lucide-react';
import { analyzeBehavior } from '../services/geminiService';
import { SecurityEvent, AIAnalysis, RiskLevel } from '../types';
import { useTranslation } from '../App';

/* Fixed sampleLogs: Added missing severity to satisfy SecurityEvent interface */
const sampleLogs: SecurityEvent[] = [
  { id: '1', deviceId: 'WK-FIN-01', tenantId: 'TEN-01', timestamp: '14:00', type: 'USB_INSERT', severity: RiskLevel.NORMAL, description: 'Unknown USB', riskWeight: 20, metadata: {} },
  { id: '2', deviceId: 'WK-FIN-01', tenantId: 'TEN-01', timestamp: '14:05', type: 'FILE_ACCESS', severity: RiskLevel.NORMAL, description: 'Accessed /Finance/Payroll', riskWeight: 10, metadata: {} },
  { id: '3', deviceId: 'WK-FIN-01', tenantId: 'TEN-01', timestamp: '14:10', type: 'NETWORK_UPLOAD', severity: RiskLevel.ELEVATED, description: '2GB Upload to personal-drive.io', riskWeight: 30, metadata: {} },
];

const AIInsights: React.FC = () => {
  const { lang, t } = useTranslation();
  const isRtl = lang === 'ar';
  const [loading, setLoading] = useState(false);
  const [analysis, setAnalysis] = useState<AIAnalysis | null>(null);

  const runAnalysis = async () => {
    setLoading(true);
    try {
      const result = await analyzeBehavior(sampleLogs);
      setAnalysis(result);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      <div className={`flex justify-between items-start ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
        <div className={isRtl ? 'text-right' : 'text-left'}>
          <div className={`flex items-center gap-4 mb-3 ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
            <h2 className="text-4xl font-extrabold tracking-tighter">{t('intelligence')}</h2>
            <div className="glass px-3 py-1 rounded-lg flex items-center gap-2 border-emerald-500/20">
              <Sparkles className="w-3 h-3 text-emerald-400" />
              <span className="text-[10px] font-black text-emerald-400 tracking-widest uppercase">Adaptive Core v3</span>
            </div>
          </div>
          <p className="text-zinc-500 font-medium">{t('neuralProcessing')}</p>
        </div>
        <button 
          onClick={runAnalysis}
          disabled={loading}
          className={`flex items-center gap-3 px-8 py-4 bg-zinc-100 hover:bg-emerald-400 disabled:opacity-50 text-zinc-950 font-black rounded-2xl transition-all shadow-2xl shadow-emerald-500/20 ${loading ? 'animate-pulse' : ''} ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}
        >
          {loading ? <RefreshCw className="w-5 h-5 animate-spin" /> : <BrainCircuit className="w-5 h-5" />}
          {loading ? (isRtl ? 'جاري التنبؤ...' : 'FORECASTING...') : (isRtl ? 'تحليل الأنماط والارتباط' : 'RUN CORRELATION ANALYSIS')}
        </button>
      </div>

      {!analysis && !loading ? (
        <div className="glass border-dashed border-zinc-800 rounded-[3rem] h-[500px] flex flex-col items-center justify-center text-center p-12 relative overflow-hidden">
          <div className="w-24 h-24 glass rounded-[2.5rem] flex items-center justify-center mb-8 border-zinc-700 opacity-20 shadow-2xl">
            <BrainCircuit className="w-12 h-12 text-zinc-700" />
          </div>
          <h3 className="text-2xl font-black mb-4">{isRtl ? 'بانتظار الارتباط' : 'Correlation Engine Offline'}</h3>
          <p className="text-zinc-500 max-w-sm">
             {isRtl ? 'قم بتشغيل المحلل للبحث عن التهديدات المخبأة والأنماط المعقدة.' : 'Run the analyzer to uncover hidden persistent threats and complex exfiltration sequences.'}
          </p>
        </div>
      ) : loading ? (
        <div className="flex flex-col items-center justify-center h-[500px]">
           <div className="w-32 h-32 bg-emerald-500/10 rounded-full flex items-center justify-center neural-pulse mb-8">
              <BrainCircuit className="w-16 h-16 text-emerald-500" />
           </div>
           <p className="text-sm font-black text-zinc-500 uppercase tracking-[0.4em]">{isRtl ? 'محاكاة السيناريوهات التنبؤية' : 'Simulating Predictive Scenarios'}</p>
        </div>
      ) : analysis && (
        <div className={`grid grid-cols-1 xl:grid-cols-3 gap-10 ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
          <div className="xl:col-span-2 space-y-8">
            <div className={`glass p-10 rounded-[3rem] relative overflow-hidden transition-all border-l-8 ${analysis.threatDetected ? 'border-rose-500 neon-glow-rose' : 'border-emerald-500 neon-glow-emerald'}`}>
              <div className={`flex justify-between items-start mb-10 ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
                <div className={isRtl ? 'text-right' : 'text-left'}>
                  <span className="text-[10px] font-black text-zinc-500 uppercase tracking-[0.3em] mb-3 block">{t('executiveAssessment')}</span>
                  <h3 className="text-2xl font-extrabold max-w-2xl leading-snug tracking-tight">
                    {analysis.summary}
                  </h3>
                </div>
                <div className={`p-5 rounded-3xl glass ${analysis.threatDetected ? 'text-rose-500' : 'text-emerald-500'}`}>
                  {analysis.threatDetected ? <ShieldAlert className="w-10 h-10" /> : <ShieldCheck className="w-10 h-10" />}
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="p-6 glass rounded-2xl bg-zinc-900/40">
                  <div className={`flex items-center gap-2 text-zinc-500 mb-4 ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
                    <LineChart className="w-3 h-3" />
                    <span className="text-[9px] font-black uppercase">{t('riskScore')}</span>
                  </div>
                  <p className={`text-4xl font-black ${analysis.behaviorScore > 60 ? 'text-rose-500' : 'text-emerald-500'}`}>{analysis.behaviorScore}</p>
                </div>
                
                <div className="p-6 glass rounded-2xl bg-zinc-900/40">
                  <div className={`flex items-center gap-2 text-zinc-500 mb-4 ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
                    <TrendingUp className="w-3 h-3" />
                    <span className="text-[9px] font-black uppercase">{t('threatProbability')}</span>
                  </div>
                  <p className={`text-4xl font-black ${analysis.predictiveForecast.probability7d > 50 ? 'text-rose-500' : 'text-zinc-200'}`}>
                    {analysis.predictiveForecast.probability7d}%
                  </p>
                </div>

                <div className="p-6 glass rounded-2xl bg-zinc-900/40">
                  <div className={`flex items-center gap-2 text-zinc-500 mb-4 ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
                    <Clock className="w-3 h-3" />
                    <span className="text-[9px] font-black uppercase">{t('timeToEscalation')}</span>
                  </div>
                  <p className="text-xl font-black text-zinc-200">{analysis.predictiveForecast.timeToEscalation}</p>
                </div>
              </div>
            </div>

            <div className="glass p-10 rounded-[3rem]">
               <div className={`flex items-center gap-4 mb-10 ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
                <LayoutList className="w-6 h-6 text-emerald-500" />
                <h4 className="text-xl font-extrabold tracking-tight uppercase tracking-widest">{t('topRiskFactors')}</h4>
              </div>
              <div className="space-y-3">
                {analysis.predictiveForecast.topRiskFactors.map((factor, idx) => (
                  <div key={idx} className={`p-4 bg-zinc-900/50 rounded-xl border border-zinc-800 flex items-center gap-4 ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
                    <div className="w-6 h-6 rounded-full bg-rose-500/10 flex items-center justify-center text-rose-500 text-[10px] font-bold">!</div>
                    <span className="text-sm font-medium text-zinc-300">{factor}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-8">
            <div className="glass p-8 rounded-[3rem] bg-zinc-950 border-emerald-500/20 shadow-2xl">
              <h4 className={`text-emerald-500 font-black text-[10px] tracking-[0.3em] mb-6 uppercase text-left`}>{t('edgeDirectives')}</h4>
              <div className="space-y-4">
                {analysis.recommendedActions.map((action, idx) => (
                  <button key={idx} className="w-full flex items-center justify-between p-4 bg-zinc-900 border border-zinc-800 rounded-xl hover:border-emerald-500/50 transition-all text-left">
                    <span className="text-[10px] font-black uppercase text-zinc-300">{action.replace('_', ' ')}</span>
                    <ChevronRight className="w-4 h-4 text-emerald-500" />
                  </button>
                ))}
              </div>
            </div>

            <div className="glass p-8 rounded-[3rem]">
              <h4 className={`font-black text-[10px] text-zinc-600 tracking-[0.3em] uppercase mb-8 text-left`}>{t('neuralFidelity')}</h4>
              <div className="flex items-center justify-center py-6">
                <div className="relative w-40 h-40">
                  <svg className="w-full h-full transform -rotate-90">
                    <circle cx="80" cy="80" r="70" stroke="currentColor" strokeWidth="8" fill="transparent" className="text-zinc-800" />
                    <circle cx="80" cy="80" r="70" stroke="currentColor" strokeWidth="8" fill="transparent" strokeDasharray="440" strokeDashoffset="44" className="text-emerald-500" />
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-3xl font-black">94.2%</span>
                    <span className="text-[8px] font-black text-zinc-500 uppercase tracking-widest">Confidence</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AIInsights;
