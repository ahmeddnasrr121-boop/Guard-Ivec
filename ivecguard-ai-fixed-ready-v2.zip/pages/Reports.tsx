
import React, { useState } from 'react';
import { 
  FileText, 
  Download, 
  Clock, 
  ShieldCheck, 
  ArrowRight,
  Printer,
  Calendar,
  Loader2,
  CheckCircle2
} from 'lucide-react';

const ReportCard: React.FC<{ 
  title: string; 
  desc: string; 
  type: string; 
  lastGenerated: string;
}> = ({ title, desc, type, lastGenerated }) => {
  const [isDownloading, setIsDownloading] = useState(false);
  const [isDone, setIsDone] = useState(false);

  const handleDownload = () => {
    setIsDownloading(true);
    setTimeout(() => {
      setIsDownloading(false);
      setIsDone(true);
      setTimeout(() => setIsDone(false), 2000);
    }, 1500);
  };

  return (
    <div className="bg-zinc-900 border border-zinc-800 p-6 rounded-2xl hover:border-emerald-500/50 transition-all group flex flex-col">
      <div className="flex justify-between items-start mb-6">
        <div className="p-3 bg-zinc-800 rounded-xl text-zinc-400 group-hover:text-emerald-500 transition-colors">
          <FileText className="w-6 h-6" />
        </div>
        <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-1 bg-zinc-800 text-zinc-500 rounded border border-zinc-700">
          {type}
        </span>
      </div>
      <h3 className="text-lg font-bold mb-2 tracking-tight">{title}</h3>
      <p className="text-sm text-zinc-400 mb-6 leading-relaxed flex-1">{desc}</p>
      <div className="flex items-center justify-between border-t border-zinc-800 pt-4 mt-auto">
        <div className="flex items-center gap-2 text-xs text-zinc-500">
          <Clock className="w-3 h-3" />
          {lastGenerated}
        </div>
        <div className="flex gap-2">
          <button className="p-2 hover:bg-zinc-800 rounded-lg text-zinc-400 transition-colors" title="Print">
            <Printer className="w-4 h-4" />
          </button>
          <button 
            onClick={handleDownload}
            disabled={isDownloading}
            className={`p-2 ${isDone ? 'bg-emerald-500/20 text-emerald-400' : 'bg-emerald-500 text-zinc-950'} rounded-lg hover:bg-emerald-400 transition-colors relative`} 
            title="Download PDF"
          >
            {isDownloading ? <Loader2 className="w-4 h-4 animate-spin" /> : isDone ? <CheckCircle2 className="w-4 h-4" /> : <Download className="w-4 h-4" />}
          </button>
        </div>
      </div>
    </div>
  );
};

const Reports: React.FC = () => {
  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-2 duration-500">
      <div className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-bold mb-2 tracking-tight">Compliance & Reporting</h2>
          <p className="text-zinc-400">Generate auditable PDF reports for security stakeholders.</p>
        </div>
        <button className="flex items-center gap-2 px-4 py-2 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 rounded-xl text-sm font-bold transition-all">
          <Calendar className="w-4 h-4" />
          Schedule Automations
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <ReportCard 
          title="Daily Risk Score Summary" 
          desc="Aggregate daily risk scores across all active device agents, highlighting scores > 60." 
          type="System" 
          lastGenerated="Today, 04:00 AM" 
        />
        <ReportCard 
          title="Data Loss (DLP) Audit" 
          desc="Detailed breakdown of USB insertions, file modifications, and large network uploads." 
          type="Forensic" 
          lastGenerated="Yesterday" 
        />
        <ReportCard 
          title="Employee Behavior Baseline" 
          desc="AI-generated report comparing current activity against historical working patterns." 
          type="AI Insight" 
          lastGenerated="3 days ago" 
        />
        <ReportCard 
          title="Phishing Exposure Report" 
          desc="List of detected suspicious sender domains and flagged URLs from company email logs." 
          type="Security" 
          lastGenerated="Today, 10:22 AM" 
        />
        <ReportCard 
          title="Agent Command History" 
          desc="Audit trail of all administrative remote actions (Workstation Lock, Process Kill)." 
          type="Compliance" 
          lastGenerated="Weekly" 
        />
        <div className="bg-zinc-900 border border-zinc-800 border-dashed p-6 rounded-2xl flex flex-col items-center justify-center text-center hover:border-emerald-500/50 transition-all group cursor-pointer">
          <div className="p-4 bg-zinc-800/50 rounded-full mb-4 group-hover:scale-110 transition-transform">
            <ShieldCheck className="w-8 h-8 text-zinc-500 group-hover:text-emerald-500" />
          </div>
          <h4 className="font-bold mb-1">Custom Query</h4>
          <p className="text-xs text-zinc-500 mb-4">Build a custom filter-based report</p>
          <button className="text-emerald-500 text-sm font-bold flex items-center gap-1 hover:gap-2 transition-all">
            Start Builder <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="bg-emerald-500/5 border border-emerald-500/10 p-6 rounded-3xl">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-emerald-500/20 rounded-2xl flex items-center justify-center text-emerald-500">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h4 className="font-bold text-emerald-400">SOC2 Compliance Helper</h4>
            <p className="text-sm text-zinc-400">Your current reporting settings cover 88% of required SOC2 Type II audit artifacts. Add "Access Audit" for 100%.</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reports;
