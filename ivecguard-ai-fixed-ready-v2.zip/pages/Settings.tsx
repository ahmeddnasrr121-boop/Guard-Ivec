
import React, { useState, useEffect } from 'react';
import { Save, Shield, Printer, Activity, Trash2, Plus, Loader2 } from 'lucide-react';
import { useTranslation } from '../App';
import { api } from '../services/api';
import { TenantConfig } from '../types';

const Settings: React.FC = () => {
  const { lang, t } = useTranslation();
  const isRtl = lang === 'ar';
  const [config, setConfig] = useState<TenantConfig | null>(null);
  const [printLimit, setPrintLimit] = useState(0);
  const [riskDecay, setRiskDecay] = useState(0);
  const [keywords, setKeywords] = useState<string[]>([]);
  const [newKeyword, setNewKeyword] = useState('');
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    api.getTenantConfig().then((data) => {
      setConfig(data);
      setPrintLimit(data.thresholds.printLimit);
      setRiskDecay(Math.round(data.thresholds.riskDecayRate * 100));
      setKeywords(data.keywords);
    }).catch(console.error);
  }, []);

  const handleSave = async () => {
    setIsSaving(true);
    try {
      await api.updateConfig({
        printLimit,
        riskDecayRate: riskDecay,
        keywords
      });
      alert("Configuration Saved.");
    } finally {
      setIsSaving(false);
    }
  };

  if (!config) return <div className="p-20 text-center"><Loader2 className="w-10 h-10 animate-spin mx-auto text-emerald-500" /></div>;

  return (
    <div className="space-y-10 animate-in fade-in duration-700">
      <div className={`flex justify-between items-end ${isRtl ? 'flex-row-reverse' : 'flex-row'}`}>
        <div>
          <h2 className="text-4xl font-extrabold tracking-tighter mb-2">Governance</h2>
          <p className="text-zinc-500 font-medium">Tenant Thresholds • {config.name}</p>
        </div>
        <button 
          onClick={handleSave} disabled={isSaving}
          className="bg-emerald-500 text-zinc-950 px-8 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-emerald-500/20 flex items-center gap-2"
        >
          {isSaving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
          {isRtl ? 'حفظ' : 'Save'}
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-8 gap-8">
        <div className="lg:col-span-5 space-y-8">
          <section className="glass p-10 rounded-[3rem]">
            <h3 className="text-xl font-bold mb-8 flex items-center gap-2"><Activity className="w-5 h-5" /> Thresholds</h3>
            <div className="grid grid-cols-1 gap-8">
              <div className="space-y-4">
                <label className="text-[10px] font-black text-zinc-500 uppercase">Print Threshold (Pages)</label>
                <input type="number" value={printLimit} onChange={(e) => setPrintLimit(parseInt(e.target.value))}
                       className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-4 text-sm font-bold" />
              </div>
              <div className="space-y-4">
                <label className="text-[10px] font-black text-zinc-500 uppercase">Decay Rate ({riskDecay}%)</label>
                <input type="range" min="1" max="50" value={riskDecay} onChange={(e) => setRiskDecay(parseInt(e.target.value))}
                       className="w-full accent-emerald-500" />
              </div>
            </div>
          </section>

          <section className="glass p-10 rounded-[3rem]">
            <h3 className="text-xl font-bold mb-8 flex items-center gap-2"><Shield className="w-5 h-5 text-rose-500" /> Watchwords</h3>
            <div className="flex gap-3 mb-6">
              <input type="text" value={newKeyword} onChange={(e) => setNewKeyword(e.target.value)}
                     className="flex-1 bg-zinc-900 border border-zinc-800 rounded-xl p-4 text-sm font-bold" placeholder="New Keyword..." />
              <button onClick={() => { if(newKeyword){ setKeywords([...keywords, newKeyword]); setNewKeyword(''); } }} 
                      className="p-4 bg-zinc-100 text-zinc-950 rounded-xl"><Plus className="w-5 h-5" /></button>
            </div>
            <div className="flex flex-wrap gap-2">
              {keywords.map((kw, i) => (
                <div key={i} className="glass px-3 py-2 rounded-lg border border-rose-500/20 flex items-center gap-2">
                  <span className="text-xs text-zinc-300 font-bold">{kw}</span>
                  <Trash2 className="w-3 h-3 text-zinc-600 cursor-pointer hover:text-rose-500" onClick={() => setKeywords(keywords.filter(k => k !== kw))} />
                </div>
              ))}
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default Settings;
