
import os
import time
import json
import hmac
import hashlib
import requests
import threading
import socket
from datetime import datetime

# Windows Specific Imports
try:
    import win32serviceutil
    import win32service
    import win32event
    import servicemanager
    import win32print
    import wmi
    import pyHook
    import pythoncom
except ImportError:
    print("Dependencies missing. Install pywin32, wmi, and pyhook.")

class IVECGuardService(win32serviceutil.ServiceFramework):
    _svc_name_ = "IVECGuardAgent"
    _svc_display_name_ = "IVECGuard Security & Intelligence Agent"
    _svc_description_ = "Monitors device security, print metadata, and behavioral anomalies."

    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        self.hWaitStop = win32event.CreateEvent(None, 0, 0, None)
        self.is_running = True
        self.orchestrator = SecurityOrchestrator()

    def SvcStop(self):
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        win32event.SetEvent(self.hWaitStop)
        self.is_running = False

    def SvcDoRun(self):
        servicemanager.LogMsg(servicemanager.SERVICE_WIN32_OWN_PROCESS,
                              servicemanager.PYS_SERVICE_STARTED,
                              (self._svc_name_, ''))
        self.orchestrator.run()

class SecurityOrchestrator:
    def __init__(self):
        self.config = {
            "API_URL": "https://api.ivecguard.ai/v1/telemetry",
            "TOKEN": "AGENT_SECURE_TOKEN_2025",
            "SECRET": "HMAC_SECRET_KEY_PROD",
            "TENANT_ID": "TEN-ALPHA"
        }
        self.event_buffer = []

    def log_event(self, event_type, desc, weight, meta={}):
        event = {
            "type": event_type,
            "description": desc,
            "weight": weight,
            "timestamp": datetime.utcnow().isoformat(),
            "metadata": meta
        }
        self.event_buffer.append(event)
        self.dispatch()

    def dispatch(self):
        """Batch and sign telemetry before sending"""
        if not self.event_buffer: return
        
        payload = {
            "agent_id": socket.gethostname(),
            "tenant_id": self.config["TENANT_ID"],
            "events": self.event_buffer
        }
        
        # Production Integrity Signature
        sig = hmac.new(self.config["SECRET"].encode(), 
                       json.dumps(payload).encode(), 
                       hashlib.sha256).hexdigest()
        
        try:
            requests.post(self.config["API_URL"], json=payload, headers={"X-IVEC-SIG": sig}, timeout=5)
            self.event_buffer = []
        except:
            pass # Cache for offline mode

    def monitor_usb(self):
        """WMI Loop for Sub-second detection"""
        c = wmi.WMI()
        watcher = c.watch_for(notification_type="Creation", wmi_class="Win32_USBHub")
        while True:
            dev = watcher()
            self.log_event("USB", f"Device Mounted: {dev.DeviceID}", 35)

    def monitor_print_spooler(self):
        """Audits Windows Print Jobs"""
        while True:
            # win32print.EnumJobs logic here
            time.sleep(2)

    def run(self):
        threading.Thread(target=self.monitor_usb, daemon=True).start()
        threading.Thread(target=self.monitor_print_spooler, daemon=True).start()
        while True:
            time.sleep(1)

if __name__ == '__main__':
    if len(sys.argv) > 1:
        win32serviceutil.HandleCommandLine(IVECGuardService)
    else:
        # Development Run
        SecurityOrchestrator().run()
