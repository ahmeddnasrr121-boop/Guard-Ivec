
import { Device, SecurityEvent, Command, TenantConfig } from '../types';

const API_BASE = '/api/v1';

class ApiClient {
  public isOffline: boolean = false;

  private async request<T>(path: string, options?: RequestInit): Promise<T> {
    try {
      // Ensure path doesn't result in double slashes if API_BASE ends with one or path starts with one
      const normalizedPath = path.startsWith('/') ? path : `/${path}`;
      const url = `${API_BASE}${normalizedPath}`;
      
      const response = await fetch(url, {
        ...options,
        headers: {
          'Content-Type': 'application/json',
          ...options?.headers,
        },
      });
      
      if (!response.ok) {
        throw new Error(`API Error: ${response.status} at ${url}`);
      }
      
      this.isOffline = false;
      return response.json();
    } catch (error) {
      console.error(`Request Failed: ${path}`, error);
      this.isOffline = true;
      throw error;
    }
  }

  async getTenantConfig(): Promise<TenantConfig> {
    return this.request<TenantConfig>('/admin/config');
  }

  async updateConfig(config: { printLimit: number; riskDecayRate: number; keywords: string[] }): Promise<void> {
    await this.request('/admin/config', {
      method: 'PUT',
      body: JSON.stringify(config),
    });
  }

  async getDevices(): Promise<Device[]> {
    return this.request<Device[]>('/admin/devices');
  }

  async updateDevicePolicy(deviceId: string, policy: Record<string, boolean>): Promise<void> {
    await this.request(`/admin/devices/${deviceId}/policy`, {
      method: 'PUT',
      body: JSON.stringify(policy),
    });
  }

  async getEvents(): Promise<SecurityEvent[]> {
    return this.request<SecurityEvent[]>('/admin/events');
  }

  async getCommandHistory(): Promise<any[]> {
    return this.request('/admin/commands/history');
  }

  async sendCommand(deviceId: string, action: Command['action']): Promise<void> {
    await this.request('/admin/commands', {
      method: 'POST',
      body: JSON.stringify({ deviceId, action }),
    });
  }
}

export const api = new ApiClient();
