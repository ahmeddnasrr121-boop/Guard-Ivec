import { SecurityEvent, AIAnalysis } from "../types";

// IMPORTANT:
// Never call GenAI providers directly from the browser.
// This service calls the backend AI endpoint, which holds the API key server-side.

const API_BASE = "/api/v1";

const calculateHeuristicAnalysis = (events: SecurityEvent[]): AIAnalysis => {
  let riskScore = 0;
  for (const e of events) riskScore += e.riskWeight || 0;

  const threatDetected = riskScore >= 60;
  return {
    summary:
      "Heuristic analysis (offline): correlation inferred from weighted event threshold. Configure server-side AI to enable LLM summaries.",
    threatDetected,
    correlationChain: ["Heuristic correlation"],
    recommendedActions: riskScore > 80 ? ["lock_device", "isolate_network"] : ["monitor_closely"],
    behaviorScore: Math.min(riskScore, 100),
    predictiveForecast: {
      probability7d: Math.min(riskScore * 0.8, 100),
      topRiskFactors: ["Recent high-weight event sequence"],
      timeToEscalation: threatDetected ? "Immediate" : "Unknown",
    },
  };
};

export const analyzeBehavior = async (events: SecurityEvent[]): Promise<AIAnalysis> => {
  try {
    const res = await fetch(`${API_BASE}/ai/analyze`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ events }),
    });
    if (!res.ok) throw new Error(`AI API error ${res.status}`);
    return (await res.json()) as AIAnalysis;
  } catch (err) {
    console.error("AI Insights backend error:", err);
    return calculateHeuristicAnalysis(events);
  }
};
